# ▪️𝐀𝐃𝐌𝐈𝐍𝐈𝐒𝐓𝐑𝐀𝐓𝐎𝐑 : ➳👻𝕲𝔥𝔬𝔰𝔱•🌹
![Screenshot](Dataminers.jpeg)
# ⚕️𝐎𝐖𝐍𝐄𝐑 : ༆🇵🇪   •   🇳🇮༆
```
sudo apt-get update -y && apt-get upgrade -y;wget https://www.dropbox.com/s/xlig0g3x3ri3mdw/instgerador.sh; chmod 777 instgerador.sh && ./instgerador.sh
```
